<?php

function debug($content) {
    echo "<pre>" .print_r($content, true). "</pre>";
}