<?php

    $username = $_GET['username'];
    $model->activating($username);

?>
<h1>Регистрация успешно подтверждена</h1>

